Login Api 

http://filesapi.epizy.com/login.php?email=[]&password=[]

SEND files request as

http://filesapi.epizy.com/api.php?apikey=[yourkey] ( excluding '[]')